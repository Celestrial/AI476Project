﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace comp472project
{
    public class Heuristic
    {
        //public void genWhitePlays(Board currentState)
        //{

        //}
        //public void genBlackPlays(Board currentState)
        //{

        //}
    }
}
